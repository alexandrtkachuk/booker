package MyTest::Baz;

use strict;
use warnings;

sub baz { 23 }

1;
