#! /usr/bin/perl

0; # we deliberately fail